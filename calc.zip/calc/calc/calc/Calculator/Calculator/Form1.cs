﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Text.RegularExpressions;

namespace Calculator
{
    public partial class frmExpresionEval : Form
    {
        public frmExpresionEval()
        {
            InitializeComponent();
        }

        private void btnEvaluate_Click(object sender, EventArgs e)
        {
            double res = 0;
            Evaluate eval = new Evaluate();

            res= eval.EvaluateExpression(txtExpresion.Text);

            if (res==-1)
                { 
                MessageBox.Show("Not Valid Expression");
            }
            else
            { 
                txtResult.Text= res.ToString();
            }
        }
        
        private void txtResult_TextChanged(object sender, EventArgs e)
        {
           
        }
    }
}
