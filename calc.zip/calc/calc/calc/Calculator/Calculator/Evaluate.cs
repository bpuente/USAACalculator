﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Text.RegularExpressions;

namespace Calculator
{
    public class Evaluate
    {
        MSScriptControl.ScriptControl sc = new MSScriptControl.ScriptControl();
        public double EvaluateExpression(string expression)
        {
            Double result = 0;
            String exp = "";
            int indexV = 0;
            int indexV2 = 0;
            //Regex regex = new Regex(@"([-+]?[0-9]*\.?[0-9]+[\/\+\-\*])+([-+]?[0-9]*\.?[0-9]+)");
            //Match match;
            sc.Language = "VBScript";
            exp = expression;
            //match=regex.Match(exp);

            //if (match.Success)
            //{
            try
            {
                //SQR(A)

                if (exp.ToLower().Contains("sqrt"))
                {
                    exp = exp.ToLower().Replace("sqrt", "sqr");
                }

                // Parentesis

                if (!exp.ToLower().Contains("sqr") && exp.Contains("("))
                {

                    indexV = exp.IndexOf('(');
                    indexV2 = exp.IndexOf(')');
                    if ((indexV - 1) >= 0)
                    {
                        exp = exp.Replace("(", "*");
                    }
                    else
                    {
                        exp = exp.Replace(")", "");
                    }

                    if ((indexV2 + 1) < exp.Length)
                    {
                        exp = exp.Replace("(", "*");
                    }
                    else
                    {
                        exp = exp.Replace("(", "");
                    }
                }
                if (exp.Contains("++") || exp.Contains("--") || exp.Contains("**") || exp.Contains("//"))
                {
                    return -1;
                }
                result = sc.Eval(exp);
            }
            catch
            {
                
                return -1;
            }

            return result;
            //}
            //else
            //{
            //    MessageBox.Show("Not Valid Expression");
            //    return -1;
            //}
        }
    }
}
