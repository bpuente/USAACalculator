﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using Calculator;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace Calculator.Tests
{
    [TestClass()]
    public class frmExpresionEvalTests
    {
        Evaluate eval=new Evaluate();

        [TestMethod()]
        public void SimpleBinaryExpressionValid()
        {
            string binaryExp = "1+4";
            double Val = eval.EvaluateExpression(binaryExp);

            Assert.IsTrue(Val >= 0);
        }

        [TestMethod()]
        public void SimpleBinaryExpressionInValid()
        {
            string binaryExp = "1++2";
            double Val = eval.EvaluateExpression(binaryExp);

            Assert.IsTrue(Val== -1);
        }

        [TestMethod()]
        public void POWExpresionValid()
        {
            string binaryExp = "10^2";
            double Val = eval.EvaluateExpression(binaryExp);

            Assert.IsTrue(Val >= 0);
        }

        [TestMethod()]
        public void POWExpresionInValid()
        {
            string binaryExp = "10^^2";
            double Val = eval.EvaluateExpression(binaryExp);

            Assert.IsTrue(Val== -1);
        }
        
        [TestMethod()]
        public void SQRTExpresionValid()
        {
            string binaryExp = "SQRT(5^4)";
            double Val = eval.EvaluateExpression(binaryExp);

            Assert.IsTrue(Val >= 0);
        }

        [TestMethod()]
        public void SQRTExpresionInValid()
        {
            string binaryExp = "SQRT(5/)";
            double Val = eval.EvaluateExpression(binaryExp);

            Assert.IsTrue(Val == -1);
        }

    }
}